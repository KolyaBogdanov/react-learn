export default function HeaderLeft () {
    return (
        <div className='header_left'>
            <a>
                <img src="Logo.png" className="logo_img" />
            </a>
        </div>
    )
}


