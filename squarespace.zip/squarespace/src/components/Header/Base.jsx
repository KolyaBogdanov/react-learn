import './Header.css'

const base = [{ name: '', mail: '' }];
export default function Base () {
    return (
        <></>
    )
}